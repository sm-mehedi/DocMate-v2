<?php
class Doctor {
    private $conn;
    function __construct($c){ $this->conn = $c; }

    function create($uid, $d){
        $q = $this->conn->prepare(
            "INSERT INTO doctors 
            (user_id, name, degree, phone, bmdc, nid, address, chamber, available_days, description) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        return $q->execute([
            $uid,
            $d['name'] ?? '',
            isset($d['degree']) ? implode(',', $d['degree']) : '',
            $d['phone'] ?? '',
            $d['bmdc'] ?? '',
            $d['nid'] ?? '',
            $d['address'] ?? '',
            $d['chamber'] ?? '',
            isset($d['days']) ? implode(',', $d['days']) : '',
            $d['desc'] ?? ''
        ]);
    }

    function all(){
        return $this->conn->query("SELECT * FROM doctors")->fetchAll(PDO::FETCH_ASSOC);
    }
}
