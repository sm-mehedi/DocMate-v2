<?php
require "../app/config/database.php";
require "../app/core/auth.php";
require "../app/models/Booking.php";

$q = $conn->prepare("SELECT id, name FROM patients WHERE user_id=?");
$q->execute([$_SESSION['user_id']]);
$patient = $q->fetch(PDO::FETCH_ASSOC);

$bookingModel = new Booking($conn);
$bookedDoctors = $bookingModel->myBookings($patient['id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Bookings</title>
    <link rel="stylesheet" href="../public/assets/css/patient_dashboard.css">
</head>
<body>
<nav>
    <div class="nav-left">Patient View</div>
    <div class="nav-right">
        <a href="./patient.php">Doctors</a>
        <a href="./my_bookings.php">My Bookings</a>
        <a href="./medicines.php">Medicines</a>

        <div class="dropdown">
            <?= htmlspecialchars($patient['name']) ?>
            <div class="dropdown-content">
                <a href="../public/logout.php">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
<h2>My Booked Doctors</h2>

<?php if(empty($bookedDoctors)): ?>
<p>You have no booked doctors yet.</p>
<?php else: ?>
<div class="cards">
<?php foreach($bookedDoctors as $d): ?>
    <div class="card">
        <h3><?= htmlspecialchars($d['name']) ?></h3>
        <p><strong>Phone:</strong> <?= htmlspecialchars($d['phone']) ?></p>
        <p><strong>Degree:</strong> <?= htmlspecialchars($d['degree']) ?></p>
        <p><strong>BMDC:</strong> <?= htmlspecialchars($d['bmdc'] ?? 'N/A') ?></p>
        <p><strong>Chamber:</strong> <?= htmlspecialchars($d['chamber'] ?? 'N/A') ?></p>
        <p><strong>Available Days:</strong> <?= htmlspecialchars($d['available_days']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($d['description'] ?? '') ?></p>
        <button onclick="unbookDoctor(<?= $d['id'] ?>)">Unbook</button>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<script>
function unbookDoctor(id){
    fetch("../public/unbook.php", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ doctor: id })
    }).then(()=> location.reload());
}
</script>
</body>
</html>
