<?php
require "../app/config/database.php";
require "../app/core/auth.php";
require "../app/models/Booking.php";

$booking = new Booking($conn);
$patients = $booking->forDoctor($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Booked Patients</title>
    <link rel="stylesheet" href="../public/assets/css/doctor.css">
</head>
<body>

<div class="container">
    <h2>My Booked Patients</h2>

    <?php if (empty($patients)): ?>
        <p class="no-patients">No patients have booked yet.</p>
    <?php else: ?>
        <div class="cards">
            <?php foreach ($patients as $p): ?>
            <div class="card">
                <h3><?= htmlspecialchars($p['name']) ?></h3>
                <p><strong>Phone:</strong> <?= htmlspecialchars($p['phone']) ?></p>
                <p><strong>Health Issues:</strong> <?= htmlspecialchars($p['health_issues']) ?></p>
                <p><strong>Emergency Contact:</strong> <?= htmlspecialchars($p['emergency']) ?></p>
                <p><strong>NID:</strong> <?= htmlspecialchars($p['nid']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <br>
    <a href="../public/logout.php" class="logout-btn">Logout</a>
</div>

</body>
</html>
